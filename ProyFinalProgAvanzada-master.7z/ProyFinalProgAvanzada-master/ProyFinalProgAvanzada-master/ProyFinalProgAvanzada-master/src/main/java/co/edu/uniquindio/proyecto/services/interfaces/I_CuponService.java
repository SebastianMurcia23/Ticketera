package co.edu.uniquindio.proyecto.services.interfaces;

public interface I_CuponService {

    void crearCupon()throws Exception;
    void eliminarCupon()throws Exception;
    void actualizarCupon()throws Exception;
    void listarCupones()throws Exception;
    void buscarCupon()throws Exception;

}
