package co.edu.uniquindio.proyecto.model.enums;

public enum TipoEvento {
    CONCIERTOS,TEATRO,PETICION,FOROS,FAMILIA,FESTIVAL;
}
