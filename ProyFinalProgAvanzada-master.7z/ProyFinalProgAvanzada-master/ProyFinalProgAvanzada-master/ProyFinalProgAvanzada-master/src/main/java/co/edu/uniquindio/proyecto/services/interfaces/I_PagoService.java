package co.edu.uniquindio.proyecto.services.interfaces;

import co.edu.uniquindio.proyecto.model.Pago;

public interface I_PagoService {

    void realizarPago(  )throws Exception;
    void  mostrarPago(  )throws Exception;

}
