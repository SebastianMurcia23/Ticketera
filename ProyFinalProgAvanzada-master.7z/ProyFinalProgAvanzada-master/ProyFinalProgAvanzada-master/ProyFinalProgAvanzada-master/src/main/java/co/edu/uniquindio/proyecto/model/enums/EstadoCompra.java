package co.edu.uniquindio.proyecto.model.enums;

public enum EstadoCompra {
    EN_PROCESO,CANCELADA,FINALIZADA;
}
