package co.edu.uniquindio.proyecto.model.enums;

public enum TipoSolicitud {
    QUEJA,RECLAMO,PETICION,SOLICITUD;
}
