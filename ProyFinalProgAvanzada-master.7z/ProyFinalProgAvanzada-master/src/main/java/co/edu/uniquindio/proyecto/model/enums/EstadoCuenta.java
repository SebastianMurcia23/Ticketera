package co.edu.uniquindio.proyecto.model.enums;

public enum EstadoCuenta {
    ACTIVA,POR_ACTIVAR,INACTIVA;
}
