package co.edu.uniquindio.proyecto.DTO;

public record EliminarEventoDTO(

        String idEvento

) {
}
