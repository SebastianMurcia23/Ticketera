package co.edu.uniquindio.proyecto.DTO;

public record ResponderPQRS_DTO(

        String idPQRS,
        String idAdmin,
        String titulo,
        String mensaje
) {
}
