package co.edu.uniquindio.proyecto.services.interfaces;

public interface I_QRService {

    void generarQR()throws Exception;

}
