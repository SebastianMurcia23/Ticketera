package co.edu.uniquindio.proyecto.model.enums;

public enum MetodoPago {
    TARJETA,EFECTIVO,TRANSFERENCIA;
}
