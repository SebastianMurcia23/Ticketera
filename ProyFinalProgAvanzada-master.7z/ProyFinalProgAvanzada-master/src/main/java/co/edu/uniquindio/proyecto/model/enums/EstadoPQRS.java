package co.edu.uniquindio.proyecto.model.enums;

public enum EstadoPQRS {
    PENDIENTE,EN_REVISION,SOLUCIONADA,CANCELADA;
}
