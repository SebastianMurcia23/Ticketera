package co.edu.uniquindio.proyecto.model.enums;

public enum TipoCupon {
    UNICO,MULTIPLE;
}
