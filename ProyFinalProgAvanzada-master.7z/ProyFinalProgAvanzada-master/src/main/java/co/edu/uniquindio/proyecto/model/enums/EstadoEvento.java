package co.edu.uniquindio.proyecto.model.enums;

public enum EstadoEvento {
    ACTIVO,INACTIVO,EN_ELABORACION;
}
