package co.edu.uniquindio.proyecto.model.enums;

public enum EstadoCupon {
    DISPONIBLE,NO_DISPONIBLE, INACTIVO;
}
