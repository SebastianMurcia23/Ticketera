package co.edu.uniquindio.proyecto.model.enums;

public enum EstadoPago {
    RECHAZADO,PENDIENTE,APROBADO;
}
