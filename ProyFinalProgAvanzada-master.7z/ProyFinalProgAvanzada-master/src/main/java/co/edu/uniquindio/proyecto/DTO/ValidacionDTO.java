package co.edu.uniquindio.proyecto.DTO;

public record ValidacionDTO(

        String campo,
        String mensaje
) {
}
